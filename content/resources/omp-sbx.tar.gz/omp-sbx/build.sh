#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMAGE="${OMP_SBX_IMAGE:-omp-sbx:latest}"
OMP_VERSION="${OMP_VERSION:-latest}"

command -v docker >/dev/null || { echo "error: docker is required" >&2; exit 1; }
command -v sbx >/dev/null || {
  echo "error: Docker sbx CLI is required (install/enable sbx first)" >&2
  exit 1
}

echo "==> building ${IMAGE} (OMP_VERSION=${OMP_VERSION})"
docker build \
  --build-arg "OMP_VERSION=${OMP_VERSION}" \
  -t "${IMAGE}" \
  -f "${ROOT}/sbx-kit/Dockerfile" \
  "${ROOT}"

echo "==> loading image into sbx"
TAR="$(mktemp "${TMPDIR:-/tmp}/omp-sbx.XXXXXX.tar")"
trap 'rm -f "$TAR"' EXIT

docker image save "${IMAGE}" -o "$TAR"
sbx template load "$TAR"

echo "==> smoke test"
NAME="omp-build-verify-$$"
cleanup() { sbx rm -f "$NAME" >/dev/null 2>&1 || true; }
trap cleanup EXIT

sbx create -q \
  --name "$NAME" \
  --kit "${ROOT}/sbx-kit" \
  --template "${IMAGE}" \
  omp /tmp

sleep 2
sbx exec "$NAME" omp --version

echo "✓ OMP sbx template is ready."
echo
echo "Run from a project directory:"
echo "  sbx create --kit \"${ROOT}/sbx-kit\" --template \"${IMAGE}\" omp ."
echo "  sbx run --name omp"
echo
echo "Pin an OMP release if desired:"
echo "  OMP_VERSION=<version> ./build.sh"

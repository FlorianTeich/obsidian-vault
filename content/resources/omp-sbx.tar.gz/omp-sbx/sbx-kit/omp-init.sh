#!/usr/bin/env bash
set -euo pipefail

cd /home/agent/workspace
exec omp "$@"

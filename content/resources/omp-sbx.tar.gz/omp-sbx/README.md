# omp-sbx

Minimal Docker `sbx` wrapper for [Oh My Pi](https://github.com/can1357/oh-my-pi).

## Build

```bash
./build.sh
```

The build script:
1. builds the custom `omp-sbx:latest` image,
2. saves it as a Docker image archive,
3. loads the archive into `sbx`,
4. creates a temporary sandbox and runs `omp --version`.

The OMP release is resolved at image-build time. Pin it with:

```bash
OMP_VERSION=16.1.15 ./build.sh
```

## Run

From the project you want OMP to work on:

```bash
sbx create \
  --name omp-my-project \
  --kit ./sbx-kit \
  --template omp-sbx:latest \
  omp .

sbx run --name omp-my-project
```

The kit starts OMP automatically.

## Persistent OMP state

The kit expects the host's `~/.omp` to be available as an sbx workspace mount and links it to `/home/agent/.omp`. This keeps OMP state outside the microVM.

## Security

Do not mount host credential stores unless you explicitly want the agent to have those credentials. The supplied network policy is intentionally limited to common model/package/GitHub endpoints; add domains only when needed.

`sbx` supplies the actual isolation boundary. Avoid adding Docker privileges, host sockets, `NET_ADMIN`, or broad host mounts to this kit.
